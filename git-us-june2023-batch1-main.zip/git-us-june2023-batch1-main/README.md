# Git Basics Training ( June 2023 - US Batch1 )

## My LinkedIn Profile
https://www.linkedin.com/in/jeganathan-swaminathan-2a6a6a6/

## My YouTube Channel
https://www.youtube.com/@JeganathanSwaminathan/videos

## My Medium Blogs
https://medium.com/@jegan_50867

## For training/consulting enquires, you may reach me at the below email
jegan@tektutor.org
